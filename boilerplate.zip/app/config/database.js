const db = {
    host: 'localhost',
    port: 3306,
    database: 'ni_db',
    user: 'root',
    password: '',
}

module.exports = db;