const routes = {
    '/': 'MainController',
    '_404': 'MainController/_404',
}

module.exports = routes;